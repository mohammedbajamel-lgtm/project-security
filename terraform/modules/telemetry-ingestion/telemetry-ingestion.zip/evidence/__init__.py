"""Immutable forensic evidence packaging."""
