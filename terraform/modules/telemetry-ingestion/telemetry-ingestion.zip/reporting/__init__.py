"""Incident report generation."""
