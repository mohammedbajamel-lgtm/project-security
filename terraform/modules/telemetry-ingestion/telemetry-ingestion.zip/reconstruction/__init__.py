"""Deterministic attack reconstruction."""
